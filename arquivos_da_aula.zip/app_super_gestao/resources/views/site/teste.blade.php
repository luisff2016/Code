P1 = {{ $xyz }}
<br />
P1 = {{ $zzz }}
